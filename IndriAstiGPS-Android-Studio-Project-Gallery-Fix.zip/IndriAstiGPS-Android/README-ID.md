# Indri Asti GPS Camera — proyek Android

Proyek Android Studio yang membungkus file HTML ke dalam WebView lokal menggunakan `WebViewAssetLoader` (`https://appassets.androidplatform.net/...`). Ini menyediakan secure context untuk `getUserMedia()` dan Geolocation tanpa server Termux.

## Yang disiapkan
- File aplikasi `app/src/main/assets/index.html` disimpan di dalam APK.
- Izin Android kamera, lokasi presisi/perkiraan, dan mikrofon untuk perekaman video bersuara.
- WebView dengan JavaScript, penyimpanan lokal, izin kamera/mikrofon, dan geolocation.
- Ikon dan nama aplikasi `Indri Asti GPS Camera`.
- Fitur utama bisa dibuka offline. Peta OpenStreetMap, reverse geocoding, dan sinkronisasi waktu online tetap butuh internet.

## Membuat APK dengan Android Studio

1. Di komputer, pasang Android Studio terbaru dengan Android SDK Platform 35 dan JDK 17.
2. Ekstrak ZIP proyek ini.
3. Android Studio → **Open** → pilih folder `IndriAstiGPS-Android`.
4. Tunggu Gradle Sync selesai dan izinkan Android Studio memasang komponen yang diminta.
5. Pilih **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.
7. Pindahkan APK ke HP, buka file tersebut, dan izinkan pemasangan aplikasi dari sumber itu bila diminta.

## Catatan izin
- Saat pertama dibuka, Android meminta izin kamera, lokasi, dan mikrofon. Mikrofon dipakai jika fitur rekam video bersuara digunakan.
- Aktifkan layanan Lokasi/GPS Android. Akurasi GPS bergantung pada perangkat dan kondisi sinyal.
- Jangan menutup paksa aplikasi saat sedang memakai kamera atau merekam.

## Batasan yang perlu diuji
Proyek sumber ini disiapkan, tetapi belum dikompilasi atau diuji pada perangkat Android nyata di lingkungan ini. Uji kamera depan/belakang, simpan foto, rekam video, GPS, dan penyimpanan pada HP sebelum dipakai untuk pekerjaan penting.
